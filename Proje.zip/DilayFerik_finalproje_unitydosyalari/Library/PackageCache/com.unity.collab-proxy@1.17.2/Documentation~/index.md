# About Version Control

The Version Control package provides an in-editor interface for teams to work with Plastic SCM.
## Plastic SCM

Plastic SCM Plug-in for Unity is a free Unity plug-in that gives you the ability to use Plastic SCM, a leading version control solution, directly in Unity. Get started with [Plastic SCM](QuickStartGuide.md).

