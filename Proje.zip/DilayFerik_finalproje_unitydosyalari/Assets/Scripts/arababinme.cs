using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class arababinme : MonoBehaviour
{
    public GameObject playerinArabasi;
    public GameObject DisaridakiAraba;
    public GameObject player;

    public GameObject playerinucagi;
    public GameObject disaridakiucak;
    public GameObject playeringemisi;
    public GameObject disaridakigemi;


    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(movePlayer.gemibindi==true)
        {
            if(movePlayer.denizdeyiz==false)
            {
                movePlayer.Speed = 2;
            }
            else if (movePlayer.denizdeyiz==true)
            {
                movePlayer.Speed = 50;
            }
        }
    }

    public void ARABABINVEIN()
    {
        if(movePlayer.arabayabindi==false)
        {
            if (movePlayer.aracmesafesi == true)
            {
                movePlayer.Speed = 35;
                player.transform.position = new Vector3(DisaridakiAraba.transform.position.x, player.transform.position.y, DisaridakiAraba.transform.position.z);
                player.transform.rotation = DisaridakiAraba.transform.rotation;
                playerinArabasi.SetActive(true);
                DisaridakiAraba.SetActive(false);
                movePlayer.arabayabindi = true;
            }
        }
        else if(movePlayer.arabayabindi==true)
        {
            movePlayer.Speed = 20;
            DisaridakiAraba.transform.position = playerinArabasi.transform.position;
            DisaridakiAraba.transform.rotation = playerinArabasi.transform.rotation;

            playerinArabasi.SetActive(false);
            DisaridakiAraba.SetActive(true);
            movePlayer.arabayabindi = false;
        }

        if (movePlayer.ucakbindi == false)
        {
            if (movePlayer.ucakmesafesi == true)
            {
                movePlayer.Speed = 60;
                player.transform.position = new Vector3(disaridakiucak.transform.position.x, player.transform.position.y, disaridakiucak.transform.position.z);
                player.transform.rotation = disaridakiucak.transform.rotation;
                playerinucagi.SetActive(true);
                disaridakiucak.SetActive(false);
                movePlayer.ucakbindi = true;
            }
        }
        else if (movePlayer.ucakbindi == true)
        {
            movePlayer.Speed = 20;
            disaridakiucak.transform.position = playerinucagi.transform.position;
            disaridakiucak.transform.rotation = playerinucagi.transform.rotation;

            playerinucagi.SetActive(false);
            disaridakiucak.SetActive(true);
            movePlayer.ucakbindi = false;
        }
        if (movePlayer.gemibindi == false)
        {
            if (movePlayer.gemimesafesi == true)
            {
                movePlayer.Speed = 50;
                player.transform.position = new Vector3(disaridakigemi.transform.position.x, player.transform.position.y, disaridakigemi.transform.position.z);
                player.transform.rotation = disaridakigemi.transform.rotation;
                playeringemisi.SetActive(true);
                disaridakigemi.SetActive(false);
                movePlayer.gemibindi = true;
            }
        }
        else if (movePlayer.gemibindi == true)
        {
            movePlayer.Speed = 20;
            disaridakigemi.transform.position = playeringemisi.transform.position;
            disaridakigemi.transform.rotation = playeringemisi.transform.rotation;

            playeringemisi.SetActive(false);
            disaridakigemi.SetActive(true);
            movePlayer.gemibindi = false;
        }

      




    }
}
