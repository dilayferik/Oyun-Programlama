using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(stash))]
public class collector : MonoBehaviour
{
    private stash _stash;

    private void Awake()
    {
        _stash = GetComponent<stash>();
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Collectable"))
        {
            if (other.TryGetComponent(out Collectable collected))
            {
                _stash.AddStash(collected);
            }
        }
    }

}