using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stash : MonoBehaviour
{
    public Transform stashParent;
    private GameObject x;
    public List<Stashable> CollectedObjects = new List<Stashable>();
    public int CollectedCount => CollectedObjects.Count;
    public float collectionHeight = 1;
    private int maxCollectableCount = 5;
    // Start is called before the first frame update
    void Start()
    {
        x = GameObject.FindGameObjectWithTag("Train");
    }
    private void Update()
    {

       


        if(movePlayer.arabayabindi==true)
        {
            maxCollectableCount = 10;
            
            
           
            

        }
        else if (this.gameObject == x)
        {
            maxCollectableCount = 20;
        }
        else if(movePlayer.gemibindi==true)
        {
            maxCollectableCount = 20;
        }
        else if(movePlayer.ucakbindi==true)

        {
 
            
            maxCollectableCount = 30;
        }
        else
        {
            maxCollectableCount = 5;
        }
       
    }

    public void AddStash(Collectable collectedObject)
    {
        if (CollectedCount >= maxCollectableCount)
            return;

        var yLocalPosition = CollectedCount * collectionHeight;

        var stashable = collectedObject.Collect();
        stashable.CollectStashable(stashParent, yLocalPosition, CompleteCollection);
        CollectedObjects.Add(stashable);

    }

    private void CompleteCollection()
    {


    }

    public Stashable RemoveStash()
    {
        if (CollectedCount <= 0)
            return null;

        var stashable = CollectedObjects[CollectedCount - 1];

        CollectedObjects.Remove(stashable);
        stashable.transform.parent = null;

        return stashable;

    }
}
