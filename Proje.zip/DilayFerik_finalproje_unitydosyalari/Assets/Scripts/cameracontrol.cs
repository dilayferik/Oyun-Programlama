using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameracontrol : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = Vector3.zero;

    void Start()
    {
        offset = transform.position - target.position;
    }

    
    void Update()
    {
        Vector3 pos = target.position + offset;

        transform.position = pos;
    }
}
