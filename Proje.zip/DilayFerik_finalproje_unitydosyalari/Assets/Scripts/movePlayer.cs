using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movePlayer : MonoBehaviour
{
    public VariableJoystick joystick;
    public Animator animCtrl;
    public static float Speed = 20f;
    public float RotationSpeed = 10f;

    public static bool gemimesafesi = false;
    public static bool gemibindi = false;
    public static bool denizdeyiz = false;
    
    public static bool ucakmesafesi = false;
    public static bool ucakbindi = false;
    public static bool aracmesafesi = false;
    public static bool arabayabindi = false;
    public GameObject Button;
    private void Start()
    {
        Button.SetActive(false);
    }
    void Update()
    {
        



        if (joystick == null)
            return;

        Vector2 direction = joystick.Direction;

        Vector3 movementVector = new Vector3(direction.x, 0, direction.y);

        movementVector = movementVector * Time.deltaTime * Speed;

        transform.position += movementVector;
      
        if (movementVector.magnitude != 0)
        { 
            transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.LookRotation(movementVector, Vector3.up), Time.deltaTime * RotationSpeed);
        }

        bool isWalking = direction.magnitude > 0;
        if (gemimesafesi == true || ucakmesafesi == true)
        {
            animCtrl.SetBool("isrunning", false);

            animCtrl.SetFloat("SpeedValue", 0);
        }
        else
        {
            animCtrl.SetBool("isrunning", isWalking);

            animCtrl.SetFloat("SpeedValue", direction.magnitude);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Aracabinme"))
        {
            Button.SetActive(true);
            aracmesafesi = true;
        }
        else if(other.gameObject.CompareTag("Gemi"))
        {
            Button.SetActive(true);
            gemimesafesi = true;
        }
        else if (other.gameObject.CompareTag("Ucak"))
        {
            Button.SetActive(true);
            ucakmesafesi = true;
        }

        if(other.gameObject.CompareTag("Deniz"))
        {
            if(gemibindi==true)
            {
                denizdeyiz = true;
            }
            
        }
        

    }
    private void OnTriggerExit(Collider other)
    {
        if(other.gameObject.CompareTag("Aracabinme"))
        {
            Button.SetActive(false);    
            aracmesafesi = false;
        }
        else if (other.gameObject.CompareTag("Gemi"))
        {
            Button.SetActive(false);
            gemimesafesi = false;
        }
        else if (other.gameObject.CompareTag("Ucak"))
        {
            Button.SetActive(false);
            ucakmesafesi = false;
        }
        else if (other.gameObject.CompareTag("Deniz"))
        {
            denizdeyiz = false;
            
        }

    }

}